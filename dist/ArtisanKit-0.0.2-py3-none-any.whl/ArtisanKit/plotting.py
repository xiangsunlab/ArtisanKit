# For plotting function and formats
